import org.springframework.web.bind.annotation.*;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class HandTrackingController {

    @PostMapping("/track")
    public Map<String, String> trackHand(@RequestBody Map<String, Double> data) {
        double x = data.get("x");
        double y = data.get("y");

        Map<String, String> response = new HashMap<>();
        response.put("status", "success");
        response.put("message", "Titik diterima di koordinat X: " + x + ", Y: " + y);

        System.out.println("Diterima: X = " + x + ", Y = " + y);

        return response;
    }
}
